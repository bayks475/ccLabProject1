//
//  eye.h
//  fireFlies
//
//  Created by Selin Baykal on 11/1/12.
//
//
#pragma once
#include "ofMain.h"

class eye {
public:
    
    //variables
    float x;
    float y;
    float s;
    float eyeDistance;
 
    
    //methods
	void setup();
	void update();
    void draw();

    
};
